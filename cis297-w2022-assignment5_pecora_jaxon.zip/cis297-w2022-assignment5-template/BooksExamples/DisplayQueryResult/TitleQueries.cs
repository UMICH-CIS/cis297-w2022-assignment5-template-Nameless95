﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.Entity;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DisplayQueryResult
{
    /// <summary>
    /// controls the buttons for first query
    /// </summary>
    public partial class TitleQueries : Form
    {
        /// <summary>
        /// intiliztes all components
        /// </summary>
        public TitleQueries()
        {
            InitializeComponent();
        }

        private BooksExamples.BooksEntities dbcontext = new BooksExamples.BooksEntities();
        /// <summary>
        /// loads all information from databsase into party
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void TitleQueries_Load(object sender, EventArgs e)
        {
            dbcontext.Titles.OrderBy(titles => titles.Title1).Load();

            titleBindingSource.DataSource = dbcontext.Titles.Local;
        }

   

        private void titleDataGridView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
           


        }

        /// <summary>
        /// grabs text box and search all databases for stuff in databox
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void searchbutton_Click(object sender, EventArgs e)
        {

            titleBindingSource.DataSource = dbcontext.Titles.Local.Where(title => title.Title1.Contains(userinput.Text)).OrderBy(title => title.Title1);
            titleBindingSource.MoveFirst();

        }

        /// <summary>
        /// clears all information and resets so taht all database information shows
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void resetbutton_Click(object sender, EventArgs e)
        {
            dbcontext.Titles.OrderBy(titles => titles.Title1).Load();

            titleBindingSource.DataSource = dbcontext.Titles.Local;

        }
    }
}
